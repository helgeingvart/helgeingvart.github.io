---
layout: single
title: "Publications"
permalink: /publications/
author_profile: true
---

This page will include a list of academic publications. Add them here in BibTeX, APA, or custom format.
